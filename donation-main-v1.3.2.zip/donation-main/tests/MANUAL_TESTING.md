# מדריך בדיקות ידניות - Manual Testing Guide

## תוכן העניינים - Table of Contents

1. [התקנה והגדרות - Installation & Setup](#installation--setup)
2. [בדיקות ממשק ניהול - Admin Interface Tests](#admin-interface-tests)
3. [בדיקות טופס תרומה - Donation Form Tests](#donation-form-tests)
4. [בדיקות עיצוב - Design Tests](#design-tests)
5. [בדיקות תשלום - Payment Tests](#payment-tests)
6. [בדיקות תגובה - Responsive Tests](#responsive-tests)
7. [בדיקות דפדפנים - Browser Tests](#browser-tests)

---

## Installation & Setup

### ✅ Test 1: Plugin Installation
**Steps:**
1. העלה את תיקיית `donation` ל-`/wp-content/plugins/`
2. גש לדשבורד WordPress → תוספים
3. הפעל את "Sola Donation Plugin"

**Expected Result:**
- ✓ התוסף מופעל ללא שגיאות
- ✓ מופיע תפריט "Sola Donations" בצד שמאל
- ✓ אין הודעות שגיאה ב-debug log

---

### ✅ Test 2: Default Settings
**Steps:**
1. לחץ על "Sola Donations" → "Settings"
2. בדוק את הערכים ההתחלתיים

**Expected Result:**
- ✓ Sandbox Mode מסומן כברירת מחדל
- ✓ כל השדות ריקים
- ✓ העמוד נטען מהר וללא שגיאות

---

## Admin Interface Tests

### ✅ Test 3: Save Settings
**Steps:**
1. הזן sandbox xKey: `test_key_123`
2. הזן redirect URL: `https://example.com/thank-you`
3. הזן webhook URL: `https://webhook.site/unique-url`
4. לחץ "Save Settings"

**Expected Result:**
- ✓ הודעת הצלחה: "Settings saved successfully!"
- ✓ כל השדות נשמרו נכון
- ✓ לחץ F5 - הערכים נשארים

---

### ✅ Test 4: Toggle Sandbox Mode
**Steps:**
1. סמן את Sandbox Mode
2. שמור
3. בטל את הסימון
4. שמור

**Expected Result:**
- ✓ המחוון משתנה צבע (אפור ⇄ כתום)
- ✓ השינוי נשמר בכל פעם

---

### ✅ Test 5: Shortcode Display
**Steps:**
1. מצא את קופסת "How to Use"
2. בדוק שהשורטקוד מוצג: `[sola_donation_form]`
3. לחץ על כפתור "Copy"

**Expected Result:**
- ✓ השורטקוד מוצג בקופסה
- ✓ כפתור Copy עובד (העתקה ללוח)

---

## Donation Form Tests

### ✅ Test 6: Form Display - Hebrew (RTL)
**Steps:**
1. צור עמוד חדש ב-WordPress
2. הוסף בלוק Shortcode
3. הזן: `[sola_donation_form]`
4. פרסם וצפה בעמוד

**Expected Result:**
- ✓ הטופס מוצג עם רקע כחול (#023047)
- ✓ כותרת: "תרומה בטוחה"
- ✓ כיוון RTL (טקסט מיושר לימין)
- ✓ איקונים בצד ימין של השדות
- ✓ כפתור "English" בראש הטופס

---

### ✅ Test 7: Language Toggle
**Steps:**
1. לחץ על כפתור "English"
2. חכה 0.3 שניות
3. לחץ שוב על "עברית"

**Expected Result:**
- ✓ כל הטקסטים עוברים לאנגלית
- ✓ כיוון משתנה ל-LTR (שמאל)
- ✓ איקונים עוברים לצד שמאל
- ✓ מעבר חלק (fade effect)
- ✓ אין רענון עמוד

---

### ✅ Test 8: Personal Details Section
**Steps:**
1. מלא את השדות:
   - שם פרטי: "יוסי"
   - שם משפחה: "כהן"
   - טלפון: "050-1234567"
   - מייל: "yossi@example.com"
   - כתובת: "רח' הרצל 1, תל אביב"

**Expected Result:**
- ✓ כל השדות מקבלים קלט עברי
- ✓ hover על שדה = הרמה קלה (transform)
- ✓ focus על שדה = זוהר כתום
- ✓ placeholder נעלם בעת הקלדה

---

### ✅ Test 9: Currency Selection
**Steps:**
1. לחץ על כפתור "$" (USD)
2. שים לב לכל סמלי המטבע בטופס
3. לחץ על "€" (EUR)
4. חזור ל-"₪" (ILS)

**Expected Result:**
- ✓ כפתור מסומן הופך לכתום
- ✓ כל סמלי המטבע משתנים (כפתורי סכום, כפתור תרומה)
- ✓ animation חלק בין המצבים

---

### ✅ Test 10: Donation Type Toggle
**Steps:**
1. בדוק שברירת מחדל = "חודשי"
2. לחץ על "חד פעמי"
3. חזור ל"חודשי"

**Expected Result:**
- ✓ כאשר "חודשי": שדה "יום לחיוב" מופיע
- ✓ כאשר "חד פעמי": שדה "יום לחיוב" נעלם
- ✓ slide animation חלק (300ms)

---

### ✅ Test 11: Preset Amount Buttons
**Steps:**
1. לחץ על כפתור "50"
2. לחץ על "100"
3. לחץ על "180"
4. לחץ על "500"

**Expected Result:**
- ✓ כפתור נבחר הופך לכתום עם gradient
- ✓ hover = הרמה 3px
- ✓ כפתור התרומה מתעדכן: "תרום ₪50 עכשיו" וכו'

---

### ✅ Test 12: Custom Amount Field
**Steps:**
1. לחץ על "סכום אחר"
2. הזן: 250
3. לחץ על כפתור preset
4. לחץ שוב "סכום אחר"

**Expected Result:**
- ✓ שדה מתרחב למטה (slide-down)
- ✓ focus אוטומטי על השדה
- ✓ סמל מטבע מופיע בשדה
- ✓ כפתור התרומה מתעדכן: "תרום ₪250 עכשיו"
- ✓ שדה נסגר כש לוחצים preset

---

### ✅ Test 13: Charge Day Selector
**Steps:**
1. ודא שסוג = "חודשי"
2. פתח את dropdown "יום לחיוב"
3. בחר יום 15

**Expected Result:**
- ✓ dropdown מכיל ימים 1-28
- ✓ dropdown מעוצב עם arrow
- ✓ ערך נבחר נשמר

---

### ✅ Test 14: Charge Now Checkbox
**Steps:**
1. לחץ על checkbox "לחייב את התרומה הראשונה..."
2. לחץ שוב

**Expected Result:**
- ✓ checkbox מותאם אישית (לא ברירת מחדל)
- ✓ סימון = gradient כתום + ✓
- ✓ hover על label = רקע מואר

---

### ✅ Test 15: Card Number - Type Detection
**Steps:**
1. הזן: 4111
2. המשך: 4111111111111111
3. נקה והזן: 5454545454545454
4. נקה והזן: 370276000431054

**Expected Result:**
- ✓ Visa (4...) → לוגו "VISA" מופיע
- ✓ Mastercard (5...) → לוגו "MC" מופיע
- ✓ Amex (37...) → לוגו "AMEX" מופיע
- ✓ auto-format עם רווחים: "4111 1111 1111 1111"

---

### ✅ Test 16: Expiry Date Formatting
**Steps:**
1. הזן: 12
2. המשך: 1225

**Expected Result:**
- ✓ אחרי 2 ספרות → "/" מתווסף אוטומטית
- ✓ פורמט סופי: "12/25"
- ✓ מקסימום 5 תווים (MM/YY)

---

### ✅ Test 17: CVV Validation
**Steps:**
1. הזן 3 ספרות: 123
2. נסה להזין יותר

**Expected Result:**
- ✓ מקסימום 3-4 ספרות
- ✓ רק מספרים מותרים

---

### ✅ Test 18: Security Badges
**Steps:**
1. בדוק את קטע פרטי תשלום
2. מצא את התגים:
   - "תשלום מאובטח" בכותרת
   - "מוצפן 256-bit" למטה

**Expected Result:**
- ✓ תגים עם איקוני מנעול
- ✓ רקע אפור בהיר
- ✓ מעצבים אמון

---

## Design Tests

### ✅ Test 19: Glassmorphism Effects
**Steps:**
1. צפה בכרטיסים הלבנים
2. בדוק שקיפות
3. בדוק blur ברקע

**Expected Result:**
- ✓ כרטיסים שקופים חלקית
- ✓ backdrop-filter: blur פעיל
- ✓ צללים עדינים
- ✓ גבול לבן שקוף

---

### ✅ Test 20: Floating Background Elements
**Steps:**
1. הסתכל ברקע הכחול
2. חכה 20 שניות
3. עקוב אחרי העיגולים המטושטשים

**Expected Result:**
- ✓ 2 עיגולים כתומים מטושטשים
- ✓ נעים לאט (20s animation)
- ✓ משנים מיקום וגודל
- ✓ opacity: 0.15

---

### ✅ Test 21: Hover Animations
**Steps:**
1. hover מעל שדה input
2. hover מעל כפתור סכום
3. hover מעל כרטיס (section)
4. hover מעל כפתור תרומה

**Expected Result:**
- ✓ Input: הרמה 1-2px + הארה
- ✓ כפתור: הרמה 3px + צל
- ✓ כרטיס: הרמה 4px + צל גדול
- ✓ כפתור תרומה: הרמה 3px + shimmer effect

---

### ✅ Test 22: Donate Button Animation
**Steps:**
1. הסתכל על כפתור "תרום עכשיו"
2. שים לב לאנימציה הקבועה

**Expected Result:**
- ✓ pulse animation (2s loop)
- ✓ לב פועם (heartbeat)
- ✓ gradient כתום
- ✓ shimmer על hover

---

### ✅ Test 23: Font Loading
**Steps:**
1. פתח DevTools → Network
2. רענן עמוד
3. חפש Google Fonts

**Expected Result:**
- ✓ Noto Sans Hebrew נטען
- ✓ Inter נטען
- ✓ Outfit נטען
- ✓ פונטים חלקים וקריאים

---

### ✅ Test 24: Colors Consistency
**Steps:**
1. בדוק את הצבעים בטופס
2. השווה למפרט

**Expected Result:**
- ✓ רקע: #023047 (כחול כהה)
- ✓ כפתורים פעילים: #F49431 (כתום)
- ✓ hover: #ff9d47 (כתום בהיר)
- ✓ טקסט: #023047
- ✓ רקע כרטיסים: לבן שקוף

---

## Payment Tests

### ✅ Test 25: Form Validation - Empty Fields
**Steps:**
1. לחץ על כפתור "תרום" ללא מילוי שדות
2. קרא הודעת שגיאה

**Expected Result:**
- ✓ הודעה: "אנא מלא את כל השדות הנדרשים"
- ✓ שדה error box אדום
- ✓ אין שליחת טופס

---

### ✅ Test 26: Email Validation
**Steps:**
1. הזן email לא תקין: "test"
2. לחץ "תרום"
3. תקן ל: "test@example.com"

**Expected Result:**
- ✓ שגיאה על email לא תקין
- ✓ עובר עם email תקין

---

### ✅ Test 27: Card Number Validation
**Steps:**
1. הזן מספר כרטיס קצר: "4111"
2. לחץ "תרום"

**Expected Result:**
- ✓ הודעה: "מספר כרטיס לא תקין"
- ✓ צריך לפחות 13 ספרות

---

### ✅ Test 28: Sandbox Payment - One-Time
**Steps:**
1. ודא Sandbox Mode פעיל בהגדרות
2. מלא את הטופס:
   - שם: Test User
   - מייל: test@example.com
   - טלפון: 123456789
   - כתובת: Test Address
   - מטבע: ILS
   - סוג: חד פעמי
   - סכום: 100
   - כרטיס: 4444333322221111
   - תוקף: 12/25
   - CVV: 123
3. לחץ "תרום ₪100 עכשיו"

**Expected Result:**
- ✓ כפתור מציג spinner
- ✓ כפתור disabled
- ✓ לאחר 2-5 שניות → הודעת הצלחה
- ✓ "תודה על תרומתך! העסקה בוצעה בהצלחה"
- ✓ (או הודעת שגיאה אם API לא מוגדר)

---

### ✅ Test 29: Sandbox Payment - Recurring
**Steps:**
1. מלא טופס דומה
2. שנה ל: חודשי
3. בחר יום לחיוב: 15
4. סמן: "לחייב מהחודש הנוכחי"
5. שלח

**Expected Result:**
- ✓ token נשמר
- ✓ הודעה: "Recurring donation setup successful!"
- ✓ מופיע ב-WordPress Admin → Recurring Donations

---

### ✅ Test 30: Webhook Test
**Steps:**
1. בהגדרות: הזן https://webhook.site/unique-url
2. שלח תרומה מוצלחת
3. גש ל-webhook.site

**Expected Result:**
- ✓ POST request התקבל
- ✓ JSON payload עם כל הנתונים
- ✓ כולל: donation, donor, transaction

---

### ✅ Test 31: Redirect Test
**Steps:**
1. הזן בהגדרות: https://example.com/thank-you
2. שלח תרומה מוצלחת
3. המתן 2 שניות

**Expected Result:**
- ✓ דף מפנה אוטומטית ל-URL שהוגדר

---

## Responsive Tests

### ✅ Test 32: Desktop View (1920x1080)
**Steps:**
1. פתח בחלון מלא
2. בדוק layout

**Expected Result:**
- ✓ שדות זה ליד זה (50% רוחב)
- ✓ כפתורי סכום בשורה אחת
- ✓ מקסימום רוחב: 900px
- ✓ ממורכז

---

### ✅ Test 33: Tablet View (768px)
**Steps:**
1. שנה גודל חלון ל-768px רוחב
2. בדוק layout

**Expected Result:**
- ✓ שדות עדיין זה ליד זה
- ✓ כפתורי סכום - 2 בשורה
- ✓ "סכום אחר" - רוחב מלא

---

### ✅ Test 34: Mobile View (375px)
**Steps:**
1. פתח DevTools → Toggle Device Toolbar
2. בחר iPhone X (375px)
3. בדוק layout

**Expected Result:**
- ✓ כל השדות מלאים רוחב (100%)
- ✓ שדות מסודרים אנכית
- ✓ כפתורי סכום - 1 בשורה
- ✓ כפתור תרומה - רוחב מלא
- ✓ טקסט קריא

---

### ✅ Test 35: Mobile - Language Toggle
**Steps:**
1. במובייל, החלף שפה
2. בדוק RTL/LTR

**Expected Result:**
- ✓ כיוון משתנה נכון
- ✓ כפתור שפה - רוחב מלא
- ✓ אין גלילה אופקית

---

## Browser Tests

### ✅ Test 36: Chrome
**Expected:** ✓ הכל עובד

### ✅ Test 37: Firefox
**Expected:** ✓ הכל עובד

### ✅ Test 38: Safari
**Expected:** ✓ הכל עובד (בדוק backdrop-filter)

### ✅ Test 39: Edge
**Expected:** ✓ הכל עובד

### ✅ Test 40: Mobile Safari (iOS)
**Expected:** ✓ עיצוב נכון, inputs פונקציונליים

---

## Summary Checklist

### סה"כ בדיקות - Total Tests: 40

- [ ] Installation (2)
- [ ] Admin Interface (3)
- [ ] Form Display (13)
- [ ] Design (6)
- [ ] Payment (7)
- [ ] Responsive (4)
- [ ] Browsers (5)

---

## צילומי מסך מומלצים - Recommended Screenshots

1. ✅ טופס בעברית (RTL) - Form in Hebrew
2. ✅ טופס באנגלית (LTR) - Form in English
3. ✅ hover על כפתור - Button hover state
4. ✅ מסך הגדרות - Settings page
5. ✅ הודעת הצלחה - Success message
6. ✅ הודעת שגיאה - Error message
7. ✅ mobile view - Mobile responsive
8. ✅ card detection - Card type logo

---

## Notes

- 🔴 **Critical**: Tests 28-31 (Payment)
- 🟡 **Important**: Tests 6-18 (Form)
- 🟢 **Nice to have**: Tests 19-24 (Design)

**בהצלחה! Good luck testing!** 🚀
